<?php

class TimberPage extends TimberPost
{

}
